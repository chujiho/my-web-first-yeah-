import React, { useState, useEffect } from 'react';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  doc, 
  serverTimestamp, 
  query, 
  orderBy,
  getDocs,
  setDoc
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Wind, Cake, Award, MessageCircle, Edit2, Check, X, Send } from 'lucide-react';

// --- Profanity Filter ---
const BANNED_WORDS = ['바보', '멍청이', '나쁜말', '욕설', '비방']; // Common examples
function filterText(text: string) {
  let filtered = text;
  BANNED_WORDS.forEach(word => {
    const reg = new RegExp(word, 'gi');
    filtered = filtered.replace(reg, '*'.repeat(word.length));
  });
  return filtered;
}

// --- Components ---

const Windmill = () => (
  <div className="relative w-24 h-40">
    {/* Stand */}
    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-24 bg-gray-200 border-2 border-gray-400 rounded-t-lg" />
    {/* Blades */}
    <motion.div 
      className="absolute top-8 left-1/2 -translate-x-1/2 w-32 h-32"
      animate={{ rotate: 360 }}
      transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
    >
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1 h-32 bg-gray-400" />
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-32 h-1 bg-gray-400" />
      {[0, 90, 180, 270].map((deg) => (
        <div 
          key={deg}
          className="absolute top-1/2 left-1/2 w-12 h-6 bg-white border border-gray-300 opacity-80"
          style={{ transform: `rotate(${deg}deg) translate(8px, -12px)`, borderRadius: '4px 20px 4px 4px' }}
        />
      ))}
    </motion.div>
  </div>
);

const Cloud = ({ delay = 0, y = 0 }: { delay?: number, y?: number }) => (
  <motion.div 
    className="absolute text-white opacity-60"
    initial={{ x: -200, y }}
    animate={{ x: '110vw' }}
    transition={{ duration: 40, repeat: Infinity, delay, ease: "linear" }}
  >
    <div className="w-24 h-10 bg-white rounded-full relative">
      <div className="absolute -top-4 left-4 w-12 h-12 bg-white rounded-full" />
      <div className="absolute -top-6 left-10 w-16 h-16 bg-white rounded-full" />
    </div>
  </motion.div>
);

export default function App() {
  const [achievements, setAchievements] = useState<any[]>([]);
  const [comments, setComments] = useState<any[]>([]);
  const [newComment, setNewComment] = useState({ author: '', text: '' });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState({ title: '', content: '' });

  // Fetch Achievements
  useEffect(() => {
    const q = query(collection(db, 'achievements'), orderBy('updatedAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setAchievements(data);
      // Initialize with default if empty
      if (data.length === 0) {
        setDoc(doc(db, 'achievements', 'initial'), {
          title: '첫 번째 업적',
          content: '여기에 업적을 작성해주세요! 누구나 수정할 수 있습니다.',
          updatedAt: serverTimestamp()
        });
      }
    }, (err) => handleFirestoreError(err, OperationType.GET, 'achievements'));
    return () => unsubscribe();
  }, []);

  // Fetch Comments
  useEffect(() => {
    const q = query(collection(db, 'comments'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setComments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (err) => handleFirestoreError(err, OperationType.GET, 'comments'));
    return () => unsubscribe();
  }, []);

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.author || !newComment.text) return;
    try {
      await addDoc(collection(db, 'comments'), {
        author: newComment.author,
        text: filterText(newComment.text),
        createdAt: serverTimestamp()
      });
      setNewComment({ author: '', text: '' });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'comments');
    }
  };

  const startEdit = (item: any) => {
    setEditingId(item.id);
    setEditContent({ title: item.title, content: item.content });
  };

  const saveEdit = async () => {
    if (!editingId) return;
    try {
      await updateDoc(doc(db, 'achievements', editingId), {
        title: editContent.title,
        content: editContent.content,
        updatedAt: serverTimestamp()
      });
      setEditingId(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'achievements');
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden font-sans">
      {/* Background: Sky & Meadow */}
      <div className="fixed inset-0 z-0 bg-sky-300">
        <Cloud y={50} delay={0} />
        <Cloud y={150} delay={10} />
        <Cloud y={100} delay={25} />
        <div className="absolute bottom-0 w-full h-[40vh] bg-lime-400 rounded-[100%_100%_0_0] scale-[1.5] translate-y-1/4 shadow-inner" />
        <div className="absolute bottom-10 left-[20%] z-10 opacity-80">
          <Windmill />
        </div>
      </div>

      {/* Main Content */}
      <main className="relative z-20 container mx-auto px-4 py-12 max-w-2xl">
        <motion.header 
          className="text-center mb-12"
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          <h1 className="text-6xl font-bold text-blue-800 drop-shadow-md mb-2">chujiho</h1>
          <p className="text-xl text-blue-600 bg-white/50 inline-block px-4 py-1 rounded-full">추지호의 소중한 공간</p>
        </motion.header>

        {/* Birthday Section */}
        <Section icon={<Cake className="text-pink-500" />} title="생일">
          <div className="text-3xl text-center py-4 text-pink-600 font-bold">
            2004년 4월 14일
          </div>
          <p className="text-center text-gray-600 mt-2">이 세상에 선물처럼 나타난 날 ✨</p>
        </Section>

        {/* Achievements (Wiki) Section */}
        <Section 
          icon={<Award className="text-yellow-500" />} 
          title="업적 (누구나 수정 가능!)"
          action={
            <div className="text-xs text-gray-500 flex items-center gap-1">
              <Edit2 size={12} /> 나무위키처럼 수정해보세요
            </div>
          }
        >
          <div className="space-y-6">
            {achievements.map((item) => (
              <div key={item.id} className="relative bg-amber-50/50 p-4 rounded-xl border-2 border-amber-200">
                {editingId === item.id ? (
                  <div className="space-y-3">
                    <input 
                      className="w-full p-2 rounded border border-amber-300 bg-white outline-none focus:ring-2 ring-amber-400"
                      value={editContent.title}
                      onChange={(e) => setEditContent({ ...editContent, title: e.target.value })}
                      placeholder="제목"
                    />
                    <textarea 
                      className="w-full p-2 rounded border border-amber-300 bg-white min-h-[150px] outline-none focus:ring-2 ring-amber-400"
                      value={editContent.content}
                      onChange={(e) => setEditContent({ ...editContent, content: e.target.value })}
                      placeholder="내용"
                    />
                    <div className="flex gap-2 justify-end">
                      <button onClick={() => setEditingId(null)} className="p-2 text-gray-500 hover:bg-gray-100 rounded-full"><X size={20} /></button>
                      <button onClick={saveEdit} className="p-2 text-green-600 hover:bg-green-100 rounded-full"><Check size={20} /></button>
                    </div>
                  </div>
                ) : (
                  <>
                    <h3 className="text-2xl font-bold text-amber-800 mb-2">{item.title}</h3>
                    <p className="text-lg text-amber-900 whitespace-pre-wrap leading-relaxed">{item.content}</p>
                    <button 
                      onClick={() => startEdit(item)}
                      className="absolute top-2 right-2 p-2 text-amber-400 hover:text-amber-600 transition-colors"
                    >
                      <Edit2 size={18} />
                    </button>
                    <div className="mt-4 text-[10px] text-amber-400 italic">
                      마지막 수정: {item.updatedAt?.toDate ? item.updatedAt.toDate().toLocaleString('ko-KR') : '방금'}
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </Section>

        {/* Comments Section */}
        <Section icon={<MessageCircle className="text-blue-500" />} title="방명록 (댓글)">
          <form onSubmit={handleAddComment} className="mb-8 bg-blue-50 p-6 rounded-2xl border-2 border-blue-100 space-y-4">
            <div className="flex gap-4">
              <input 
                className="w-1/3 p-3 rounded-xl border-2 border-blue-200 bg-white outline-none focus:ring-2 ring-blue-400 placeholder-blue-300"
                placeholder="너의 이름"
                value={newComment.author}
                onChange={(e) => setNewComment({ ...newComment, author: e.target.value })}
              />
              <div className="flex-1 relative">
                <input 
                  className="w-full p-3 pr-12 rounded-xl border-2 border-blue-200 bg-white outline-none focus:ring-2 ring-blue-400 placeholder-blue-300"
                  placeholder="따뜻한 한마디 남겨줘!"
                  value={newComment.text}
                  onChange={(e) => setNewComment({ ...newComment, text: e.target.value })}
                />
                <button 
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors shadow-sm"
                >
                  <Send size={18} />
                </button>
              </div>
            </div>
            <p className="text-xs text-blue-400">* 고운 말을 사용해주세요. 나쁜 말은 필터링됩니다!</p>
          </form>

          <div className="space-y-4">
            <AnimatePresence initial={false}>
              {comments.map((comment) => (
                <motion.div 
                  key={comment.id}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  className="bg-white/80 p-4 rounded-2xl shadow-sm border border-blue-50"
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className="font-bold text-blue-700">{comment.author}</span>
                    <span className="text-[10px] text-gray-400">
                      {comment.createdAt?.toDate ? comment.createdAt.toDate().toLocaleDateString('ko-KR') : '방금'}
                    </span>
                  </div>
                  <p className="text-gray-700">{comment.text}</p>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </Section>

        <footer className="text-center py-8 text-blue-800/50 text-sm">
          © 2026 chu ji ho. 모두가 함께 만들어가는 공간.
        </footer>
      </main>
    </div>
  );
}

function Section({ icon, title, children, action }: any) {
  return (
    <motion.section 
      className="bg-white/90 backdrop-blur-sm rounded-[2rem] p-8 mb-8 shadow-xl border-4 border-white overflow-hidden relative"
      initial={{ scale: 0.9, opacity: 0 }}
      whileInView={{ scale: 1, opacity: 1 }}
      viewport={{ once: true }}
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gray-50 rounded-2xl border-2 border-gray-100">{icon}</div>
          <h2 className="text-3xl font-bold text-gray-800">{title}</h2>
        </div>
        {action}
      </div>
      {children}
      {/* Decorative tape */}
      <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-20 h-8 bg-blue-100/40 rotate-1 rounded-sm" />
    </motion.section>
  );
}
